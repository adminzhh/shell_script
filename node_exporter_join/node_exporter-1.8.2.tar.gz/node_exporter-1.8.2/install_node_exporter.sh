#!/bin/bash
# auther: taofeiyu


VERSION=1.8.2
SOFTWARE=node_exporter-${VERSION}.linux-amd64.tar.gz
URL=https://github.com/prometheus/node_exporter/releases/download/v${VERSION}/${SOFTWARE}
DOWNLOAD=./download
INSTALLDIR=/usr/local/prometheus/node_exporter
BASEDIR=${INSTALLDIR}/node_exporter-${VERSION}.linux-amd64
HOST="0.0.0.0"
PORT=59100
hostname=`hostname`


function prepare() {
   # 判断目录是否存在，若不存在则创建
   [ -d $INSTALLDIR ] || mkdir -pv ${INSTALLDIR}
   [ -d $DOWNLOAD ] || mkdir -pv ${DOWNLOAD}
   
   if [ "$ID" == "centos" ];then
     # 判断系统是否安装curl
     [ -f /usr/bin/wget ] || yum -y install wget
   fi

   # 判断文件是否存在，若不存在则下载
   [ -s ${DOWNLOAD}/${SOFTWARE} ] || wget $URL -O ${DOWNLOAD}/${SOFTWARE}
}

function install() {
  # 检查环境
  prepare

  # 解压文件软件包
  tar xf ${DOWNLOAD}/${SOFTWARE} --strip-components=1 -C ${INSTALLDIR}

  # 生成启动脚本
  cat > /etc/systemd/system/node-exporter.service <<EOF
[Unit]
Description=Prometheus-Server
After=network.target

[Service]
ExecStart=/usr/local/prometheus/node_exporter/node_exporter --web.listen-address=0.0.0.0:59100
User=root

[Install]
WantedBy=multi-user.target
EOF

     # 将服务设置为开机自启动
     systemctl daemon-reload
     systemctl enable --now node-exporter.service
     systemctl status node-exporter.service
     ss -ntl | grep 59100
}

function remove(){
  systemctl disable --now node-exporter.service
  rm -rf /etc/systemd/system/node-exporter.service $BASEDIR
  rm -fr $INSTALLDIR
}


function main() {
  case $1 in 
    install|i)
      install
      echo " ${hostname} 的node-exporter 已经部署成功![successfully]"
      ;;
    remove|r)
      remove
      echo " ${hostname} 的node-exporter 已经卸载成功~"
      ;;
    *)
      echo "Usage: $0 install[i]|remove[r]"
      ;;
  esac
}


main $1

